import { useState, useEffect, useRef } from "react";

// ── SIZE DATA ──────────────────────────────────────────────────────────────
const SIZE_GUIDE = [
  { label:"XXS", bust:"28\"", finished:"42\"", ease:"14\"", height:"Any",  idx:0 },
  { label:"XS",  bust:"31\"", finished:"45\"", ease:"14\"", height:"Any",  idx:1 },
  { label:"S",   bust:"34\"", finished:"48\"", ease:"14\"", height:"Any",  idx:2 },
  { label:"M",   bust:"36\"", finished:"50\"", ease:"14\"", height:"Any",  idx:3 },
  { label:"L",   bust:"40\"", finished:"52\"", ease:"12\"", height:"Any",  idx:4 },
  { label:"XL",  bust:"45\"", finished:"55\"", ease:"10\"", height:"Any",  idx:5 },
  { label:"2XL", bust:"48\"", finished:"57\"", ease:"9\"",  height:"Any",  idx:6 },
  { label:"3XL", bust:"53\"", finished:"59\"", ease:"6\"",  height:"Any",  idx:7 },
  { label:"4XL", bust:"57\"", finished:"61\"", ease:"4\"",  height:"Any",  idx:8 },
  { label:"5XL", bust:"61\"", finished:"65\"", ease:"4\"",  height:"Any",  idx:9 },
];

// Per-size stitch numbers [XXS,XS,S,M,L,XL,2XL,3XL,4XL,5XL]
const SIZE_NUMS = {
  saddleCO:   [22,22,22,22,24,24,24,26,26,26],
  saddleRows: [38,42,46,50,50,54,56,58,60,66],
  saddleLen:  ["6¾\"","7½\"","8\"","8¾\"","8¾\"","9½\"","9¾\"","10\"","10½\"","11½\""],
  pickupPerSaddle:[26,29,32,34,34,37,39,40,41,45],
  backCenterCO:[22,22,22,22,24,24,24,26,26,26],
  backTotal:  [74,80,86,90,92,98,102,106,108,116],
  backFinal:  [84,90,96,100,104,110,114,118,122,130],
  frontCenterCO:[14,14,14,14,16,16,16,18,18,18],
  bodyTotal:  [168,180,192,200,208,220,228,236,244,260],
  sleeveStart:[74,76,76,80,82,86,86,90,92,92],
  sleeveEnd:  [46,48,48,48,50,50,50,54,54,54],
  collarTotal:[102,102,102,102,110,110,110,118,118,118],
  decFreq:    [5,5,5,4,4,4,4,4,3,3],
  decRounds:  [14,14,14,16,16,18,18,18,19,19],
};

// ── ANIMATED STITCH CANVASES ───────────────────────────────────────────────
function KnitCanvas({ type, playing, speed = 1 }) {
  const canvasRef = useRef(null);
  const frameRef  = useRef(0);
  const rafRef    = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width, H = canvas.height;
    let frame = 0;

    const animations = {
      // Stockinette: V stitches appearing row by row
      stockinette: (f) => {
        ctx.fillStyle = "#F8F7F4";
        ctx.fillRect(0,0,W,H);
        const cols = 10, rows = 8;
        const cw = W/cols, rh = H/rows;
        const totalV = cols * rows;
        const reveal = Math.floor((f % (totalV * 6)) / 6);
        for (let i = 0; i < totalV; i++) {
          const col = i % cols, row = Math.floor(i / cols);
          const cx = col*cw + cw/2, cy = row*rh + rh/2;
          const alpha = i < reveal ? 1 : 0.08;
          ctx.strokeStyle = `rgba(71,85,105,${alpha})`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(cx - cw*0.3, cy - rh*0.3);
          ctx.quadraticCurveTo(cx, cy + rh*0.25, cx + cw*0.3, cy - rh*0.3);
          ctx.stroke();
          // legs
          ctx.beginPath();
          ctx.moveTo(cx - cw*0.3, cy - rh*0.3);
          ctx.lineTo(cx - cw*0.3, cy + rh*0.3);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(cx + cw*0.3, cy - rh*0.3);
          ctx.lineTo(cx + cw*0.3, cy + rh*0.3);
          ctx.stroke();
        }
        // animated needle
        const needleX = ((f * 2) % (W + 40)) - 20;
        ctx.strokeStyle = "#C0392B";
        ctx.lineWidth = 3;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(needleX - 15, H/2 - 5);
        ctx.lineTo(needleX + 15, H/2 + 5);
        ctx.stroke();
      },

      // Ribbing: alternating K/P columns with wave motion
      ribbing: (f) => {
        ctx.fillStyle = "#F1F0ED";
        ctx.fillRect(0,0,W,H);
        const cols = 12;
        const cw = W/cols;
        for (let c = 0; c < cols; c++) {
          const isKnit = c % 2 === 0;
          const wave = Math.sin((f * 0.04 * speed) + c * 0.8) * 3;
          ctx.strokeStyle = isKnit ? "#334155" : "#94A3B8";
          ctx.lineWidth = isKnit ? 2 : 1.2;
          ctx.beginPath();
          for (let y = 4; y < H - 4; y += 6) {
            const x = c * cw + cw/2 + wave;
            if (y === 4) ctx.moveTo(x, y);
            else ctx.lineTo(x + Math.sin(y*0.3 + f*0.06)*2, y);
          }
          ctx.stroke();
        }
        // highlight bar sweeping up
        const barY = H - ((f * 1.5 * speed) % H);
        const grad = ctx.createLinearGradient(0, barY-20, 0, barY+20);
        grad.addColorStop(0,"rgba(248,247,244,0)");
        grad.addColorStop(0.5,"rgba(248,247,244,0.4)");
        grad.addColorStop(1,"rgba(248,247,244,0)");
        ctx.fillStyle = grad;
        ctx.fillRect(0, barY-20, W, 40);
      },

      // German Short Rows: wedge-shaped rows building up
      gsr: (f) => {
        ctx.fillStyle = "#1E293B";
        ctx.fillRect(0,0,W,H);
        const totalRows = 12;
        const progress = (f * 0.5 * speed) % (totalRows * 20 + 60);
        const rowsDone = Math.min(totalRows, Math.floor(progress / 20));
        const rowH = (H-20) / totalRows;
        for (let r = 0; r < rowsDone; r++) {
          const wedge = ((r+1) / totalRows);
          const rowY = H - 10 - r * rowH;
          const rowW = wedge * (W - 20);
          const startX = (W - rowW) / 2;
          const hue = 200 + r * 8;
          ctx.fillStyle = `hsla(${hue}, 30%, ${30 + r*3}%, 0.9)`;
          ctx.fillRect(startX, rowY - rowH + 2, rowW, rowH - 2);
          // ds marker
          if (r === rowsDone - 1) {
            ctx.fillStyle = "#F59E0B";
            ctx.beginPath();
            ctx.arc(startX - 6, rowY - rowH/2, 4, 0, Math.PI*2);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(startX + rowW + 6, rowY - rowH/2, 4, 0, Math.PI*2);
            ctx.fill();
          }
        }
        // label
        ctx.fillStyle = "#94A3B8";
        ctx.font = "9px Georgia";
        ctx.textAlign = "center";
        ctx.fillText("double stitch markers", W/2, 14);
      },

      // Italian Bind-off: stitches being passed over
      italianBO: (f) => {
        ctx.fillStyle = "#0F172A";
        ctx.fillRect(0,0,W,H);
        const sts = 14;
        const stW = W / (sts + 2);
        const progress = (f * 0.3 * speed) % (sts * 15 + 60);
        const bound = Math.floor(progress / 15);
        for (let i = 0; i < sts; i++) {
          const x = stW + i * stW + stW/2;
          const isBound = i < bound;
          const isCurrent = i === bound;
          // loop
          ctx.strokeStyle = isBound ? "#334155" : isCurrent ? "#F59E0B" : "#64748B";
          ctx.lineWidth = isBound ? 1 : isCurrent ? 2.5 : 1.5;
          ctx.beginPath();
          ctx.ellipse(x, H/2, stW*0.35, 10, 0, 0, Math.PI*2);
          ctx.stroke();
          if (isBound) {
            // woven through
            ctx.strokeStyle = "#475569";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(x, H/2 - 10);
            ctx.lineTo(x, H/2 - 22);
            ctx.stroke();
          }
        }
        // yarn tail animation
        const tailX = stW + Math.min(bound, sts-1) * stW + stW/2;
        const wave = Math.sin(f * 0.08) * 8;
        ctx.strokeStyle = "#CBD5E1";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(tailX, H/2 - 10);
        ctx.quadraticCurveTo(tailX + 20 + wave, H/2 - 30, tailX + 40, H/2 - 15);
        ctx.stroke();
        ctx.fillStyle = "#64748B";
        ctx.font = "8px Georgia";
        ctx.textAlign = "center";
        ctx.fillText("Italian bind-off", W/2, H - 8);
      },

      // M1L/M1R increases: bar lift animation
      increases: (f) => {
        ctx.fillStyle = "#F8F7F4";
        ctx.fillRect(0,0,W,H);
        const cycle = (f * speed) % 120;
        // base row of stitches
        const sts = 7, stW = W/(sts+2);
        for (let i = 0; i < sts; i++) {
          const x = stW + i*stW + stW/2;
          ctx.strokeStyle = "#475569";
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(x-6, H*0.6-8);
          ctx.quadraticCurveTo(x, H*0.6+6, x+6, H*0.6-8);
          ctx.moveTo(x-6, H*0.6-8); ctx.lineTo(x-6, H*0.6+10);
          ctx.moveTo(x+6, H*0.6-8); ctx.lineTo(x+6, H*0.6+10);
          ctx.stroke();
        }
        // highlight the bar between center sts
        const barX = stW + 3*stW + stW;
        const liftY = cycle < 60 ? H*0.6 - (cycle/60)*30 : H*0.6 - 30 + ((cycle-60)/60)*30;
        const alpha = cycle < 30 ? cycle/30 : cycle < 90 ? 1 : (120-cycle)/30;
        ctx.strokeStyle = `rgba(59,130,246,${alpha})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(barX - 8, liftY);
        ctx.lineTo(barX + 8, liftY);
        ctx.stroke();
        // new stitch forming
        if (cycle > 30 && cycle < 90) {
          const progress = (cycle-30)/60;
          ctx.strokeStyle = `rgba(59,130,246,${0.8})`;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(barX-6*progress, liftY-8*progress);
          ctx.quadraticCurveTo(barX, liftY+6*progress, barX+6*progress, liftY-8*progress);
          ctx.stroke();
        }
        ctx.fillStyle = "#3B82F6";
        ctx.font = "9px Georgia";
        ctx.textAlign = "center";
        ctx.fillText(cycle < 60 ? "lifting the bar..." : "new stitch formed", W/2, H-8);
      },

      // Pickup stitches: needle sweeping along edge
      pickup: (f) => {
        ctx.fillStyle = "#1E293B";
        ctx.fillRect(0,0,W,H);
        // saddle edge
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(20, 20); ctx.lineTo(20, H-20);
        ctx.stroke();
        // row marks on saddle
        const rows = 16;
        for (let r = 0; r < rows; r++) {
          const y = 20 + (r/(rows-1))*(H-40);
          ctx.strokeStyle = r % 5 === 0 ? "#64748B" : "#334155";
          ctx.lineWidth = r % 5 === 0 ? 1.5 : 0.8;
          ctx.beginPath();
          ctx.moveTo(14, y); ctx.lineTo(26, y);
          ctx.stroke();
        }
        // needle
        const progress = (f * 0.8 * speed) % (rows * 8 + 30);
        const currentRow = Math.min(rows-1, Math.floor(progress/8));
        const needleY = 20 + (currentRow/(rows-1))*(H-40);
        ctx.strokeStyle = "#C0392B";
        ctx.lineWidth = 2.5;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(26, needleY);
        ctx.lineTo(80, needleY - 15);
        ctx.stroke();
        // picked up stitches
        for (let r = 0; r <= currentRow; r += Math.ceil(rows/10)) {
          const y = 20 + (r/(rows-1))*(H-40);
          const x = 80 + (r/rows)*80;
          ctx.fillStyle = "#64748B";
          ctx.beginPath();
          ctx.ellipse(x, y, 5, 3, 0, 0, Math.PI*2);
          ctx.fill();
          if (r > 0) {
            ctx.strokeStyle = "#475569";
            ctx.lineWidth = 1;
            const prevR = r - Math.ceil(rows/10);
            const prevY = 20 + (prevR/(rows-1))*(H-40);
            const prevX = 80 + (prevR/rows)*80;
            ctx.beginPath();
            ctx.moveTo(prevX, prevY);
            ctx.lineTo(x, y);
            ctx.stroke();
          }
        }
        ctx.fillStyle = "#64748B";
        ctx.font = "8px Georgia";
        ctx.textAlign = "left";
        ctx.fillText("3 sts per 5 rows", 30, H-8);
      },

      // Saddle: knitting back and forth
      saddleKnit: (f) => {
        ctx.fillStyle = "#F1F0ED";
        ctx.fillRect(0,0,W,H);
        const rows = 10, cols = 8;
        const rh = (H-20)/rows, cw = (W-20)/cols;
        const progress = (f * speed) % (rows * cols * 4 + 60);
        const stitchDone = Math.floor(progress/4);
        for (let r = 0; r < rows; r++) {
          const isRS = r % 2 === 0;
          for (let c = 0; c < cols; c++) {
            const idx = r*cols + (isRS ? c : cols-1-c);
            const cx = 10 + c*cw + cw/2;
            const cy = 10 + r*rh + rh/2;
            if (idx < stitchDone) {
              ctx.strokeStyle = "#475569";
              ctx.lineWidth = 1.5;
              ctx.beginPath();
              if (isRS) {
                ctx.moveTo(cx-cw*0.28,cy-rh*0.28);
                ctx.quadraticCurveTo(cx,cy+rh*0.22,cx+cw*0.28,cy-rh*0.28);
              } else {
                ctx.moveTo(cx-cw*0.28,cy+rh*0.28);
                ctx.quadraticCurveTo(cx,cy-rh*0.22,cx+cw*0.28,cy+rh*0.28);
              }
              ctx.stroke();
            }
          }
        }
        // traveling needle
        const stIdx = stitchDone % (cols);
        const rowIdx = Math.floor(stitchDone / cols) % rows;
        const isRS = rowIdx % 2 === 0;
        const nx = 10 + (isRS ? stIdx : cols-1-stIdx)*cw + cw/2;
        const ny = 10 + rowIdx*rh + rh/2;
        ctx.strokeStyle = "#C0392B";
        ctx.lineWidth = 3;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(nx-12,ny+(isRS?-8:8));
        ctx.lineTo(nx+12,ny+(isRS?8:-8));
        ctx.stroke();
        ctx.fillStyle = "#64748B";
        ctx.font = "8px Georgia";
        ctx.textAlign = "center";
        ctx.fillText(isRS ? "→ RS: knit" : "← WS: purl", W/2, H-6);
      },

      // K2tog decrease
      k2tog: (f) => {
        ctx.fillStyle = "#0F172A";
        ctx.fillRect(0,0,W,H);
        const cycle = (f * speed) % 100;
        const sts = 5, stW = W/(sts+2);
        // draw stitches
        for (let i = 0; i < sts; i++) {
          const x = stW + i*stW + stW/2;
          const merging = (i === 1 || i === 2) && cycle > 20;
          const mergeProgress = merging ? Math.min(1,(cycle-20)/40) : 0;
          const targetX = stW + 2*stW - stW/2;
          const cx = merging ? x + (targetX - x)*mergeProgress : x;
          ctx.strokeStyle = i < 2 ? "#F59E0B" : "#64748B";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.ellipse(cx, H/2, stW*0.3, 12, 0, 0, Math.PI*2);
          ctx.stroke();
          if (i > 2) {
            ctx.strokeStyle = "#475569";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.ellipse(x, H/2, stW*0.3, 12, 0, 0, Math.PI*2);
            ctx.stroke();
          }
        }
        if (cycle > 60) {
          // single merged stitch
          const alpha = (cycle-60)/40;
          ctx.strokeStyle = `rgba(34,197,94,${alpha})`;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.ellipse(stW + 2*stW, H/2, stW*0.32, 13, 0, 0, Math.PI*2);
          ctx.stroke();
        }
        ctx.fillStyle = "#94A3B8";
        ctx.font = "9px Georgia";
        ctx.textAlign = "center";
        ctx.fillText(cycle < 20 ? "2 sts" : cycle < 60 ? "merging..." : "1 st (K2tog)", W/2, H-10);
      },
    };

    const anim = animations[type] || animations.stockinette;

    const tick = () => {
      if (playing) {
        frame++;
        anim(frame);
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [type, playing, speed]);

  return (
    <canvas
      ref={canvasRef}
      width={260}
      height={140}
      style={{ width:"100%", height:"auto", display:"block", borderRadius:"2px" }}
    />
  );
}

// ── STEP ANIMATION MAP ─────────────────────────────────────────────────────
const STEP_ANIM = ["saddleKnit","pickup","increases","increases","stockinette","stockinette","k2tog","ribbing"];
const STEP_ANIM2 = [null,"gsr","gsr","gsr",null,"ribbing","italianBO","italianBO"];

// ── STEPS DATA ─────────────────────────────────────────────────────────────
const makeSteps = (si) => [
  {
    id:1, title:"Saddles", subtitle:"The Foundation", tag:"Make Two", duration:"~2 hrs each",
    overview:"Two narrow shoulder strips. Everything else grows from these. Your first saddle IS your gauge swatch.",
    sizes:{ label:"Cast On", fn:(i)=>`${SIZE_NUMS.saddleCO[i]} sts · ${SIZE_NUMS.saddleRows[i]} rows · ${SIZE_NUMS.saddleLen[i]}` },
    steps:[
      {label:"CO sts",       note:`Long-tail cast-on on US 9 / 16" circulars — ${SIZE_NUMS.saddleCO[si]} sts`},
      {label:"Row 1 (WS)",   note:"P across"},
      {label:"Row 2 (RS)",   note:"K across"},
      {label:"Repeat",       note:`${SIZE_NUMS.saddleRows[si]} rows total, then one final WS row`},
      {label:"End on RS",    note:`Break yarn, place sts on hold. Saddle = ${SIZE_NUMS.saddleLen[si]}`},
    ],
    tips:["Use a removable marker to track RS/WS","Wet block before measuring gauge","Both saddles must be identical — count rows carefully"],
    why:"The saddle sts become the back neck width. Row count = shoulder width. These proportions set the entire sweater's fit.",
    animLabel:"Stockinette flat"
  },
  {
    id:2, title:"Back", subtitle:"Short Row Shaping", tag:"Worked Flat", duration:"~4–5 hrs",
    overview:"Picks up from both saddles with a center back cast-on. German Short Rows create the neck curve so the back sits higher than the shoulders.",
    sizes:{ label:"Key numbers", fn:(i)=>`Pick up ${SIZE_NUMS.pickupPerSaddle[i]} per saddle · CO ${SIZE_NUMS.backCenterCO[i]} center · ${SIZE_NUMS.backTotal[i]} total → ${SIZE_NUMS.backFinal[i]} sts` },
    steps:[
      {label:"Pick up",      note:`RS facing: ${SIZE_NUMS.pickupPerSaddle[si]} sts along left saddle (3:5 ratio)`},
      {label:"CO center",    note:`${SIZE_NUMS.backCenterCO[si]} sts backward loop between saddles`},
      {label:"Pick up",      note:`${SIZE_NUMS.pickupPerSaddle[si]} sts along right saddle → ${SIZE_NUMS.backTotal[si]} sts total`},
      {label:"Slide sts",    note:`WS facing: slip ${SIZE_NUMS.pickupPerSaddle[si]} sts to right needle unworked`},
      {label:"GSR setup",    note:`Join yarn, P${SIZE_NUMS.backCenterCO[si]} center sts, turn, make ds`},
      {label:"12 Short Rows",note:"Turn further each time. Mark your ds with removable marker!"},
      {label:"Straight rows",note:"Work all sts in stockinette. End WS."},
      {label:"Armhole inc",  note:`K4, M1L, K to last 4, M1R, K4 — repeat → ${SIZE_NUMS.backFinal[si]} sts`},
      {label:"Hold",         note:`Break yarn, place ${SIZE_NUMS.backFinal[si]} sts on hold`},
    ],
    tips:["Mark each ds immediately — they vanish into the fabric","After short rows, back measures only ~2\" — this is correct","The unworked sts resolve naturally in straight rows"],
    why:"German Short Rows create a curved back following your posture — higher at center back, lower at shoulders. This gives the sweater its drape.",
    animLabel:"German Short Rows"
  },
  {
    id:3, title:"Left Front", subtitle:"Neck Shaping Begins", tag:"Worked Flat", duration:"~2–3 hrs",
    overview:"Picked up from the left saddle only. Short rows shape the shoulder curve while increases simultaneously build the front neck opening.",
    sizes:{ label:"Result", fn:(i)=>`Pick up ${SIZE_NUMS.pickupPerSaddle[i]} sts · 4 neck increases → ${SIZE_NUMS.pickupPerSaddle[i]+4} sts` },
    steps:[
      {label:"Pick up",      note:`RS facing, CO sts on top: ${SIZE_NUMS.pickupPerSaddle[si]} sts along left saddle from center back outward`},
      {label:"Slide",        note:"Move to opposite needle end, begin RS"},
      {label:"SR 1–4",       note:"Turn further each RS row. WS is always P across."},
      {label:"SR 5–12",      note:"Add K4, M1L at neck edge on each RS row (4 increases total)"},
      {label:"Hold",         note:"Sts on hold. Do not break yarn yet."},
    ],
    tips:["M1L always at the NECK edge (4 sts in from the center)","WS rows are always just P across — no turning on WS","You're building shoulder curve + neck opening simultaneously"],
    why:"Each increase adds 1 stitch to the neck edge that becomes part of the collar pickup later.",
    animLabel:"M1L increase"
  },
  {
    id:4, title:"Right Front", subtitle:"Mirror of Left", tag:"Worked Flat", duration:"~2–3 hrs",
    overview:"Mirror of the left front — WS rows do the turning instead of RS, and the increase is M1RP on WS rows.",
    sizes:{ label:"Result", fn:(i)=>`Pick up ${SIZE_NUMS.pickupPerSaddle[i]} sts · 4 neck increases → ${SIZE_NUMS.pickupPerSaddle[i]+4} sts` },
    steps:[
      {label:"Pick up",      note:`RS facing: ${SIZE_NUMS.pickupPerSaddle[si]} sts from outer edge of right saddle inward`},
      {label:"SR 1–4",       note:"WS rows turn further. RS rows are always K across."},
      {label:"SR 5–12",      note:"Add P4, M1RP at neck edge on each WS row (4 increases)"},
      {label:"Final row",    note:"After last RS row, do NOT turn. Break yarn."},
      {label:"Slide",        note:"Move sts to opposite end, begin RS. Sts on hold."},
    ],
    tips:["M1RP = M1R worked purlwise on WS — same lift, different stitch type","Breaking yarn keeps row counts equal on both fronts","The do-not-turn is easy to miss — it matters for symmetry"],
    why:"The break + slide ensures both fronts have worked the same number of rows, keeping the neckline symmetrical.",
    animLabel:"M1RP increase"
  },
  {
    id:5, title:"Join Fronts", subtitle:"Neckline Takes Shape", tag:"Critical Step", duration:"~30 min",
    overview:"Both front panels join into one with a backward loop CO at center front. This CO becomes the center front collar stitches later.",
    sizes:{ label:"Center Front CO", fn:(i)=>`CO ${SIZE_NUMS.frontCenterCO[i]} sts · ${SIZE_NUMS.backFinal[i]} total front sts` },
    steps:[
      {label:"Join row (RS)", note:`K right front resolving ds, CO ${SIZE_NUMS.frontCenterCO[si]} sts backward loop, K left front resolving ds`},
      {label:"Following (WS)",note:`P across all ${SIZE_NUMS.backTotal[si]} sts`},
      {label:"Straight rows", note:"Stockinette back and forth"},
      {label:"Armhole inc",   note:`K4, M1L/M1R repeats → ${SIZE_NUMS.backFinal[si]} sts`},
    ],
    tips:[`The ${SIZE_NUMS.frontCenterCO[si]} CO sts sit at the center front V of the neckline`,"These same sts get picked up for the collar at the end","Front and back should now be identical stitch counts"],
    why:"The backward loop CO is intentionally loose — those sts need to be picked up later for the collar.",
    animLabel:"Stockinette"
  },
  {
    id:6, title:"Body", subtitle:"In the Round", tag:"Join + Knit", duration:"~6–8 hrs",
    overview:"Front and back join at the underarms. From here it's simple stockinette in the round — the most meditative part of the sweater.",
    sizes:{ label:"Total sts in round", fn:(i)=>`${SIZE_NUMS.bodyTotal[i]} sts · 7.5" from underarm · then 4" ribbing` },
    steps:[
      {label:"Join",         note:`K across ${SIZE_NUMS.backFinal[si]} front sts, K across ${SIZE_NUMS.backFinal[si]} back sts, PM, join. BOR = right underarm. ${SIZE_NUMS.bodyTotal[si]} sts.`},
      {label:"Stockinette",  note:"Knit every round until body = 7.5\" from underarm"},
      {label:"Length check", note:"Stop when body is 4\" less than desired total length if adjusting"},
      {label:"Switch needles",note:"US 8 for hem"},
      {label:"Hem ribbing",  note:"K1, P1 for 4\""},
      {label:"Italian BO",   note:"2 setup rounds, then bind off"},
    ],
    tips:[`${SIZE_NUMS.bodyTotal[si]} sts — settle into a rhythm`,"The 4\" of ribbing is substantial; don't undercount","Italian bind-off: learn it once for all three ribbed edges"],
    why:"At 7.5\" from underarm the body is done — add more length here if you want a longer silhouette (budget extra yarn).",
    animLabel:"1×1 Ribbing"
  },
  {
    id:7, title:"Sleeves", subtitle:"Cap + Taper", tag:"Make Two", duration:"~4–5 hrs each",
    overview:"Picked up from the armhole with a 3-marker system. Short rows shape the sleeve cap, then knit down with paired decreases to the cuff.",
    sizes:{ label:"Key numbers", fn:(i)=>`Start: ${SIZE_NUMS.sleeveStart[i]} sts · dec every ${SIZE_NUMS.decFreq[i]} rounds × ${SIZE_NUMS.decRounds[i]} → ${SIZE_NUMS.sleeveEnd[i]} sts` },
    steps:[
      {label:"Pickup A",     note:`${Math.round(SIZE_NUMS.sleeveStart[si]/3)} sts from underarm to saddle (2:3 ratio), PM (marker 1)`},
      {label:"Saddle sts",   note:`Break yarn, place ${SIZE_NUMS.saddleCO[si]} saddle sts on needle, PM (marker 2)`},
      {label:"Pickup B",     note:`Attach yarn, ${Math.round(SIZE_NUMS.sleeveStart[si]/3)} sts from saddle to underarm, PM = BOR → ${SIZE_NUMS.sleeveStart[si]} sts`},
      {label:"10 Short Rows",note:"Work between markers only, extending sts each turn"},
      {label:"Resolve",      note:"K to BOR removing markers, resolving ds"},
      {label:"Dec rounds",   note:`Every ${SIZE_NUMS.decFreq[si]} rounds: K1, K2tog, K to 3 before BOR, K2tog-L, K1`},
      {label:"Continue",     note:`${SIZE_NUMS.decRounds[si]} decrease rounds until 12\" from underarm → ${SIZE_NUMS.sleeveEnd[si]} sts`},
      {label:"Cuff",         note:"US 8, K1P1 ribbing 4\", Italian BO"},
    ],
    tips:["K2tog-L is the pattern's preferred left-leaning dec — watch the linked video first","The 3-marker setup makes cap shaping intuitive once you see it","16\" total sleeve = 12\" stockinette + 4\" cuff"],
    why:"Short row cap creates a smooth curve without seaming. The saddle sts become the top of the sleeve cap.",
    animLabel:"K2tog-L decrease"
  },
  {
    id:8, title:"Collar", subtitle:"The Finish", tag:"Last Step", duration:"~2–3 hrs",
    overview:"Picked up all the way around the neckline. Must be 4.5–5\" to stand up as a mock turtleneck rather than flare out.",
    sizes:{ label:"Total collar sts", fn:(i)=>`${SIZE_NUMS.collarTotal[i]} sts · 4.5–5\" tall · US 7 needles` },
    steps:[
      {label:"US 7 / 16\" circ",note:"Two sizes down — this draws the collar inward"},
      {label:"Pick up back",   note:`${SIZE_NUMS.backCenterCO[si]} sts along back CO (1 per CO st)`},
      {label:"Saddles",        note:"21 sts along each saddle"},
      {label:"Left neckline",  note:"12 sts down (1:1 ratio)"},
      {label:"Center front",   note:`${SIZE_NUMS.frontCenterCO[si]} sts (1 per CO st from join step)`},
      {label:"Right neckline", note:`12 sts up → PM, join = ${SIZE_NUMS.collarTotal[si]} sts`},
      {label:"Ribbing",        note:"K1, P1 until 4.5–5\" — sample = 5\""},
      {label:"Italian BO",     note:"Same 2 setup rounds + bind off"},
    ],
    tips:["Even number of sts required for 1×1 ribbing — adjust pickup if needed","Shorter collar will flare; 5\" length is intentional","Count each of the 6 pickup sections before joining"],
    why:"Smaller needle (US 7 vs US 9) draws collar inward. The 5\" length ensures it folds into a true mock turtleneck.",
    animLabel:"Italian bind-off"
  }
];

// ── SIZING GUIDE MODAL ─────────────────────────────────────────────────────
function SizingModal({ onSelect, onClose }) {
  const [bust, setBust] = useState("");
  const [highlight, setHighlight] = useState(null);

  useEffect(() => {
    const b = parseFloat(bust);
    if (!isNaN(b) && b > 20 && b < 80) {
      const match = SIZE_GUIDE.findIndex((s,i) => {
        const next = SIZE_GUIDE[i+1];
        const lower = parseFloat(s.bust);
        const upper = next ? parseFloat(next.bust) : 999;
        return b >= lower && b < upper;
      });
      setHighlight(match >= 0 ? match : SIZE_GUIDE.length - 1);
    } else setHighlight(null);
  }, [bust]);

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(15,23,42,0.85)", zIndex:100, display:"flex", alignItems:"center", justifyContent:"center", padding:"16px" }}>
      <div style={{ background:"#F8F7F4", maxWidth:"600px", width:"100%", maxHeight:"90vh", overflowY:"auto", border:"1px solid #E2E0DA" }}>
        <div style={{ background:"#1E293B", padding:"20px 24px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <div style={{ fontSize:"9px", letterSpacing:"3px", color:"#94A3B8", textTransform:"uppercase", fontFamily:"sans-serif" }}>Great Lakes Pullover</div>
            <div style={{ fontSize:"16px", color:"#F8FAFC", fontFamily:"Georgia, serif", marginTop:"3px" }}>Find Your Size</div>
          </div>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"#64748B", fontSize:"20px", cursor:"pointer" }}>×</button>
        </div>

        <div style={{ padding:"24px" }}>
          <p style={{ fontSize:"13px", color:"#475569", lineHeight:"1.7", margin:"0 0 20px", fontFamily:"Georgia, serif" }}>
            This sweater is designed with substantial positive ease — it's meant to be oversized and cozy. Measure your <strong>actual bust</strong> at the fullest point and use the chart below. The suggested size gives you ~14" of ease for smaller sizes.
          </p>

          {/* Bust input */}
          <div style={{ background:"#fff", border:"1px solid #E2E0DA", padding:"16px", marginBottom:"20px" }}>
            <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"10px" }}>Enter your bust measurement (inches)</div>
            <input
              type="number"
              placeholder='e.g. 34"'
              value={bust}
              onChange={e => setBust(e.target.value)}
              style={{ width:"100%", padding:"10px 12px", border:"1px solid #E2E0DA", background:"#F8F7F4", fontSize:"15px", fontFamily:"Georgia, serif", color:"#1E293B", boxSizing:"border-box", outline:"none" }}
            />
            {highlight !== null && (
              <div style={{ marginTop:"12px", padding:"10px 14px", background:"#1E293B", color:"#F8FAFC", fontSize:"12px", fontFamily:"Georgia, serif" }}>
                → Suggested size: <strong>{SIZE_GUIDE[highlight].label}</strong> · Finished bust {SIZE_GUIDE[highlight].finished} · {SIZE_GUIDE[highlight].ease} ease
              </div>
            )}
          </div>

          {/* Size chart */}
          <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"10px" }}>Full size chart</div>
          <div style={{ border:"1px solid #E2E0DA", overflow:"hidden" }}>
            <div style={{ display:"grid", gridTemplateColumns:"60px 80px 90px 80px", background:"#E2E0DA", padding:"8px 12px" }}>
              {["Size","Your Bust","Finished","Ease"].map(h => (
                <div key={h} style={{ fontSize:"9px", letterSpacing:"1px", textTransform:"uppercase", color:"#475569", fontFamily:"sans-serif" }}>{h}</div>
              ))}
            </div>
            {SIZE_GUIDE.map((s, i) => (
              <div
                key={s.label}
                onClick={() => onSelect(i)}
                style={{
                  display:"grid", gridTemplateColumns:"60px 80px 90px 80px",
                  padding:"10px 12px",
                  background: highlight === i ? "#1E293B" : i % 2 === 0 ? "#fff" : "#F8F7F4",
                  cursor:"pointer",
                  borderTop:"1px solid #E2E0DA",
                  transition:"background 0.15s",
                }}
              >
                <div style={{ fontSize:"13px", fontFamily:"Georgia, serif", color: highlight===i?"#F8FAFC":"#1E293B", fontWeight: highlight===i?"bold":"normal" }}>{s.label}</div>
                <div style={{ fontSize:"12px", fontFamily:"Georgia, serif", color: highlight===i?"#CBD5E1":"#475569" }}>{s.bust}</div>
                <div style={{ fontSize:"12px", fontFamily:"Georgia, serif", color: highlight===i?"#CBD5E1":"#475569" }}>{s.finished}</div>
                <div style={{ fontSize:"12px", fontFamily:"Georgia, serif", color: highlight===i?"#94A3B8":"#94A3B8" }}>{s.ease}</div>
              </div>
            ))}
          </div>

          <p style={{ fontSize:"11px", color:"#94A3B8", lineHeight:"1.6", margin:"16px 0 0", fontFamily:"Georgia, serif" }}>
            Click any row to select that size and load all stitch numbers automatically. You can change size any time from the top bar.
          </p>
        </div>
      </div>
    </div>
  );
}

// ── MAIN APP ───────────────────────────────────────────────────────────────
export default function GreatLakesWalkthrough() {
  const [sizeIdx, setSizeIdx]       = useState(null); // null = not chosen yet
  const [showModal, setShowModal]   = useState(false);
  const [active, setActive]         = useState(0);
  const [tab, setTab]               = useState("overview");
  const [playing, setPlaying]       = useState(true);
  const [anim2, setAnim2]           = useState(false);

  // If no size selected, show splash
  if (sizeIdx === null) {
    return (
      <div style={{ fontFamily:"Georgia, serif", background:"#1E293B", minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:"24px" }}>
        {showModal && <SizingModal onSelect={i => { setSizeIdx(i); setShowModal(false); }} onClose={() => setShowModal(false)} />}
        <div style={{ maxWidth:"480px", width:"100%", textAlign:"center" }}>
          <div style={{ fontSize:"9px", letterSpacing:"4px", color:"#475569", textTransform:"uppercase", marginBottom:"16px", fontFamily:"sans-serif" }}>Ozetta · 2025</div>
          <h1 style={{ fontSize:"32px", fontWeight:"normal", color:"#F8FAFC", letterSpacing:"1px", margin:"0 0 8px" }}>Great Lakes Pullover</h1>
          <div style={{ fontSize:"12px", color:"#64748B", letterSpacing:"2px", textTransform:"uppercase", marginBottom:"40px", fontFamily:"sans-serif" }}>Visual Knitting Guide</div>

          <div style={{ background:"#0F172A", border:"1px solid #334155", padding:"32px", marginBottom:"24px" }}>
            <div style={{ fontSize:"11px", color:"#64748B", letterSpacing:"1px", textTransform:"uppercase", fontFamily:"sans-serif", marginBottom:"16px" }}>Before we begin</div>
            <p style={{ fontSize:"14px", color:"#94A3B8", lineHeight:"1.8", margin:"0 0 24px" }}>
              Select your size to load the correct stitch numbers throughout every step of the guide. All instructions will be tailored specifically to your size.
            </p>
            <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
              <button
                onClick={() => setShowModal(true)}
                style={{ background:"#F8FAFC", color:"#1E293B", border:"none", padding:"14px 24px", fontSize:"11px", letterSpacing:"2px", textTransform:"uppercase", cursor:"pointer", fontFamily:"sans-serif" }}
              >Help Me Choose My Size</button>
              <div style={{ fontSize:"10px", color:"#475569", fontFamily:"sans-serif" }}>or select directly:</div>
              <div style={{ display:"flex", flexWrap:"wrap", gap:"6px", justifyContent:"center" }}>
                {SIZE_GUIDE.map((s,i) => (
                  <button key={s.label} onClick={() => setSizeIdx(i)} style={{ background:"none", border:"1px solid #334155", color:"#94A3B8", padding:"6px 12px", fontSize:"11px", cursor:"pointer", fontFamily:"sans-serif", letterSpacing:"1px", transition:"all 0.15s" }}
                    onMouseEnter={e => { e.target.style.background="#334155"; e.target.style.color="#F8FAFC"; }}
                    onMouseLeave={e => { e.target.style.background="none"; e.target.style.color="#94A3B8"; }}
                  >{s.label}</button>
                ))}
              </div>
            </div>
          </div>
          <div style={{ fontSize:"10px", color:"#334155", fontFamily:"sans-serif", letterSpacing:"1px" }}>You can change your size at any time</div>
        </div>
      </div>
    );
  }

  const steps = makeSteps(sizeIdx);
  const step  = steps[active];
  const animType  = STEP_ANIM[active];
  const animType2 = STEP_ANIM2[active];

  return (
    <div style={{ fontFamily:"Georgia, serif", background:"#F8F7F4", minHeight:"100vh", display:"flex", flexDirection:"column" }}>
      {showModal && <SizingModal onSelect={i => { setSizeIdx(i); setShowModal(false); }} onClose={() => setShowModal(false)} />}

      {/* Header */}
      <div style={{ background:"#1E293B", color:"#F1F5F9", padding:"16px 24px", borderBottom:"1px solid #334155", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"10px" }}>
        <div>
          <div style={{ fontSize:"9px", letterSpacing:"4px", color:"#475569", textTransform:"uppercase", fontFamily:"sans-serif" }}>Ozetta · 2025</div>
          <div style={{ fontSize:"18px", color:"#F8FAFC", letterSpacing:"0.5px" }}>Great Lakes Pullover</div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          style={{ background:"#334155", border:"1px solid #475569", color:"#CBD5E1", padding:"8px 16px", fontSize:"10px", letterSpacing:"2px", textTransform:"uppercase", cursor:"pointer", fontFamily:"sans-serif", display:"flex", alignItems:"center", gap:"8px" }}
        >
          <span style={{ background:"#64748B", color:"#F8FAFC", padding:"2px 8px", fontSize:"10px", fontFamily:"sans-serif" }}>{SIZE_GUIDE[sizeIdx].label}</span>
          Change Size
        </button>
      </div>

      {/* Step nav */}
      <div style={{ background:"#F1F0ED", borderBottom:"1px solid #E2E0DA", overflowX:"auto", display:"flex", alignItems:"stretch" }}>
        {steps.map((s,i) => (
          <button key={s.id} onClick={() => { setActive(i); setTab("overview"); setAnim2(false); }}
            style={{ background:"none", border:"none", borderBottom: active===i?"2px solid #1E293B":"2px solid transparent", padding:"12px 14px", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:"3px", opacity: active===i?1:0.5, transition:"all 0.2s", minWidth:"64px", whiteSpace:"nowrap" }}
          >
            <div style={{ width:"22px", height:"22px", borderRadius:"50%", background: active===i?"#1E293B":i<active?"#64748B":"#CBD5E1", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"10px", fontFamily:"sans-serif" }}>{i<active?"✓":s.id}</div>
            <span style={{ fontSize:"8px", letterSpacing:"1px", textTransform:"uppercase", color:"#334155", fontFamily:"sans-serif" }}>{s.title}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex:1, maxWidth:"920px", margin:"0 auto", width:"100%", padding:"24px 20px" }}>

        {/* Step header */}
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"20px", flexWrap:"wrap", gap:"10px" }}>
          <div>
            <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"5px" }}>
              <span style={{ background:"#1E293B", color:"#F8FAFC", fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", padding:"3px 10px", fontFamily:"sans-serif" }}>Step {step.id} of {steps.length}</span>
              <span style={{ background:"#E2E8F0", color:"#475569", fontSize:"9px", letterSpacing:"1.5px", textTransform:"uppercase", padding:"3px 10px", fontFamily:"sans-serif" }}>{step.tag}</span>
            </div>
            <h2 style={{ margin:0, fontSize:"26px", fontWeight:"normal", color:"#1E293B" }}>{step.title}</h2>
            <div style={{ fontSize:"12px", color:"#64748B", marginTop:"2px", letterSpacing:"1px" }}>{step.subtitle}</div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:"9px", color:"#94A3B8", letterSpacing:"1px", textTransform:"uppercase", fontFamily:"sans-serif" }}>Est. time</div>
            <div style={{ fontSize:"13px", color:"#334155", marginTop:"2px" }}>{step.duration}</div>
          </div>
        </div>

        {/* Size callout */}
        <div style={{ background:"#1E293B", color:"#F8FAFC", padding:"12px 18px", marginBottom:"20px", display:"flex", alignItems:"center", gap:"12px", flexWrap:"wrap" }}>
          <span style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#64748B", fontFamily:"sans-serif" }}>Size {SIZE_GUIDE[sizeIdx].label}</span>
          <span style={{ fontSize:"13px", fontFamily:"Georgia, serif", color:"#CBD5E1" }}>{step.sizes.fn(sizeIdx)}</span>
        </div>

        {/* Main grid: animations + overview */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1.5fr", gap:"20px", marginBottom:"20px", alignItems:"start" }}>
          {/* Animations panel */}
          <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
            <div style={{ background:"#0F172A", border:"1px solid #1E293B", overflow:"hidden" }}>
              <div style={{ padding:"8px 12px", borderBottom:"1px solid #1E293B", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div style={{ fontSize:"8px", letterSpacing:"2px", textTransform:"uppercase", color:"#475569", fontFamily:"sans-serif" }}>
                  {anim2 && animType2 ? STEP_ANIM2_LABELS[active] : step.animLabel}
                </div>
                <div style={{ display:"flex", gap:"6px" }}>
                  {animType2 && (
                    <button onClick={() => setAnim2(!anim2)} style={{ background: anim2?"#334155":"none", border:"1px solid #334155", color:"#64748B", padding:"3px 8px", fontSize:"8px", cursor:"pointer", fontFamily:"sans-serif", letterSpacing:"1px" }}>
                      {anim2 ? "← 1" : "2 →"}
                    </button>
                  )}
                  <button onClick={() => setPlaying(!playing)} style={{ background:"none", border:"1px solid #334155", color:"#64748B", padding:"3px 10px", fontSize:"10px", cursor:"pointer", fontFamily:"sans-serif" }}>
                    {playing ? "⏸" : "▶"}
                  </button>
                </div>
              </div>
              <KnitCanvas type={anim2 && animType2 ? animType2 : animType} playing={playing} speed={1} />
            </div>
            {animType2 && (
              <div style={{ fontSize:"9px", color:"#94A3B8", fontFamily:"sans-serif", letterSpacing:"1px", textAlign:"center" }}>
                Toggle → to see {STEP_ANIM2_LABELS[active]}
              </div>
            )}
          </div>

          {/* Overview + size */}
          <div style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
            <div style={{ background:"#fff", border:"1px solid #E2E0DA", padding:"18px" }}>
              <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"8px" }}>What You're Building</div>
              <p style={{ margin:0, fontSize:"13px", lineHeight:"1.7", color:"#334155" }}>{step.overview}</p>
            </div>
            <div style={{ background:"#F8F7F4", border:"1px solid #E2E0DA", padding:"14px" }}>
              <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"8px" }}>Key technique this step</div>
              <div style={{ fontSize:"12px", color:"#475569", lineHeight:"1.6" }}>
                {step.id===1 && "Stockinette flat — alternate K rows (RS) and P rows (WS). Simple but sets gauge for everything."}
                {step.id===2 && "German Short Rows (GSR) — turn mid-row, create a double stitch. Resolves invisibly as you work."}
                {step.id===3 && "M1L increase — lift the bar between sts from front to back, knit through back loop."}
                {step.id===4 && "M1RP increase — same bar lift but worked purlwise on WS rows."}
                {step.id===5 && "Backward loop CO joins the two fronts. Intentionally loose so sts can be picked up for collar."}
                {step.id===6 && "Italian bind-off — the two setup rounds prepare stitches; the bind-off mimics a cast-on edge."}
                {step.id===7 && "K2tog-L — the pattern's preferred left-leaning decrease. Neater than SSK at the sleeve seam line."}
                {step.id===8 && "Smaller needle (US 7) naturally draws ribbing inward. Length is critical — under 4.5\" will flare."}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:"flex", borderBottom:"1px solid #E2E0DA", marginBottom:"18px" }}>
          {["overview","steps","tips","why"].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ background:"none", border:"none", borderBottom: tab===t?"2px solid #1E293B":"2px solid transparent", padding:"9px 16px", cursor:"pointer", fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color: tab===t?"#1E293B":"#94A3B8", fontFamily:"sans-serif", transition:"all 0.15s" }}>
              {t==="why"?"Why It Works":t}
            </button>
          ))}
        </div>

        <div style={{ background:"#fff", border:"1px solid #E2E0DA", padding:"22px", minHeight:"160px" }}>
          {tab==="overview" && (
            <div>
              <p style={{ margin:"0 0 14px", fontSize:"13px", lineHeight:"1.8", color:"#334155" }}>{step.overview}</p>
              <div style={{ fontSize:"11px", color:"#64748B", lineHeight:"1.7" }}>Use <strong>Steps</strong> for row-by-row, <strong>Tips</strong> for gotchas, <strong>Why It Works</strong> for construction logic.</div>
            </div>
          )}
          {tab==="steps" && (
            <div>
              <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"14px" }}>Instructions — Size {SIZE_GUIDE[sizeIdx].label}</div>
              {step.steps.map((s,i) => (
                <div key={i} style={{ display:"grid", gridTemplateColumns:"130px 1fr", gap:"14px", padding:"10px 0", borderBottom: i<step.steps.length-1?"1px solid #F1F0ED":"none", alignItems:"baseline" }}>
                  <div style={{ fontSize:"9px", letterSpacing:"1px", textTransform:"uppercase", color:"#1E293B", fontFamily:"sans-serif", fontWeight:"bold" }}>{s.label}</div>
                  <div style={{ fontSize:"12px", color:"#475569", lineHeight:"1.6" }}>{s.note}</div>
                </div>
              ))}
            </div>
          )}
          {tab==="tips" && (
            <div>
              <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"14px" }}>Things That Trip People Up</div>
              {step.tips.map((tip,i) => (
                <div key={i} style={{ display:"flex", gap:"12px", padding:"10px 0", borderBottom: i<step.tips.length-1?"1px solid #F1F0ED":"none", alignItems:"flex-start" }}>
                  <div style={{ width:"18px", height:"18px", background:"#F1F0ED", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"9px", color:"#64748B", flexShrink:0, fontFamily:"sans-serif" }}>{i+1}</div>
                  <div style={{ fontSize:"12px", color:"#475569", lineHeight:"1.7" }}>{tip}</div>
                </div>
              ))}
            </div>
          )}
          {tab==="why" && (
            <div>
              <div style={{ fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", color:"#94A3B8", fontFamily:"sans-serif", marginBottom:"14px" }}>Construction Logic</div>
              <p style={{ margin:0, fontSize:"13px", lineHeight:"1.9", color:"#334155", fontStyle:"italic" }}>{step.why}</p>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div style={{ display:"flex", justifyContent:"space-between", marginTop:"22px" }}>
          <button onClick={() => { setActive(Math.max(0,active-1)); setTab("overview"); setAnim2(false); }} disabled={active===0}
            style={{ background: active===0?"#F1F0ED":"#1E293B", color: active===0?"#CBD5E1":"#F8FAFC", border:"none", padding:"11px 22px", fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", cursor: active===0?"default":"pointer", fontFamily:"sans-serif" }}>
            ← Previous
          </button>
          <div style={{ fontSize:"10px", color:"#94A3B8", fontFamily:"sans-serif", alignSelf:"center", letterSpacing:"1px" }}>{active+1} / {steps.length}</div>
          <button onClick={() => { setActive(Math.min(steps.length-1,active+1)); setTab("overview"); setAnim2(false); }} disabled={active===steps.length-1}
            style={{ background: active===steps.length-1?"#F1F0ED":"#1E293B", color: active===steps.length-1?"#CBD5E1":"#F8FAFC", border:"none", padding:"11px 22px", fontSize:"9px", letterSpacing:"2px", textTransform:"uppercase", cursor: active===steps.length-1?"default":"pointer", fontFamily:"sans-serif" }}>
            Next →
          </button>
        </div>
      </div>
    </div>
  );
}

const STEP_ANIM2_LABELS = [null,"German Short Rows","German Short Rows","German Short Rows",null,"Italian bind-off","Italian bind-off","Italian bind-off"];
